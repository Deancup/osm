import xml.etree.ElementTree as ET
osm_file=r'F:\new_osm\boston_osm'
sample_file=r'F:\new_osm\sample'
k=10
def get_element(osm_file,tags=('node','way','relation')):
    context=iter(ET.iterparse(osm_file,events=('start','end')))
    _,root=next(context)
    for event, elem in context:
        if event =='end' and elem.tag in tags:
            yield elem
            root.clear()

with open(sample_file,'wb') as output:
    output.write(b'<?xml version="1.0" encoding="UTF-8"?>\n')
    output.write(b'<osm>\n  ')
    for i,elem in enumerate(get_element(osm_file)):
        if i %k==0:
            output.write(ET.tostring(elem,encoding='utf-8'))
    output.write(b'</osm>')


